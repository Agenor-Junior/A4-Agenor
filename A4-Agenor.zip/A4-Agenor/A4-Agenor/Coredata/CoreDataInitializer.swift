//
//  DatabaseFill.swift
//  A4-Agenor
//
//  Created by Agenor Dionizio da Silva Junior on 2025-07-20.
//

import Foundation
import CoreData
import UIKit

func preloadInitialDataIfNeeded(context: NSManagedObjectContext) {
    let userRequest: NSFetchRequest<User> = User.fetchRequest()
    
    do {
        let userCount = try context.count(for: userRequest)
        
        if userCount == 0 {
            let user1 = User(context: context)
            user1.name = "Alex"
            user1.password = 123

            let user2 = User(context: context)
            user2.name = "Martha"
            user2.password = 456

            let user3 = User(context: context)
            user3.name = "Jhon"
            user3.password = 789

            let books = [
                ("1984", "George Orwell"),
                ("The Hobbit", "J.R.R. Tolkien"),
                ("To Kill a Mockingbird", "Harper Lee"),
                ("Pride and Prejudice", "Jane Austen"),
                ("The Great Gatsby", "F. Scott Fitzgerald"),
                ("The Catcher in the Rye", "J.D. Salinger"),
                ("Brave New World", "Aldous Huxley"),
                ("Animal Farm", "George Orwell"),
                ("The Lord of the Rings", "J.R.R. Tolkien"),
                ("Moby-Dick", "Herman Melville")
            ]
            
            for (title, author) in books {
                let book = Book(context: context)
                book.title = title
                book.author = author
                book.borrower = ""
            }

            try context.save()
            print("Inicial Data Loaded.")
        } else {
            print("Database already filled.")
        }
    } catch {
        print("Error While Loading: \(error.localizedDescription)")
    }
}

