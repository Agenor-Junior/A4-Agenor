//
//  cellPrototype.swift
//  A4-Agenor
//
//  Created by Agenor Dionizio da Silva Junior on 2025-07-20.
//

import Foundation
import UIKit

class BookCell: UITableViewCell {
    @IBOutlet weak var titleBook: UILabel!
    @IBOutlet weak var bookStatus: UILabel!
}
