//  ViewController01_login.swift
//  A4-Agenor
//  Created by Agenor Dionizio da Silva Junior on 2025-07-16.
//  Users:
//  Name: Alex        Password: 123
//  Name: Martha      Password: 456
//  Name: Jhon        Password: 789

import UIKit
import CoreData

class ViewController01_login: UIViewController
{
    
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    
    // context variable
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad()
    {
//        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        usernameField.text = ""
        passwordField.text = ""
        errorLabel.isHidden = true
    }
    
    @IBAction func loginButton(_ sender: UIButton)
    {
        guard let name = usernameField.text, !name.isEmpty,
        let password = passwordField.text, !password.isEmpty
        else
        {
            errorLabel.text = "Please fill in both fields!"
            errorLabel.isHidden = false
            return
        }
        
        if validateUser(name: name, password: password)
        {
            errorLabel.isHidden = true
            performSegue(withIdentifier: "loginToNextScreen", sender: self)
        }
        else
        {
            errorLabel.text = "Wrong user or password!"
            errorLabel.isHidden = false
        }
    }
}

func validateUser(name: String, password: String) -> Bool
{
    let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
    fetchRequest.predicate = NSPredicate(format: "name == %@ AND password == %@", name, password)

    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    do
    {
        let users = try context.fetch(fetchRequest)
        return users.first != nil
    }
    catch
    {
        print("Erro ao buscar usuário: \(error.localizedDescription)")
        return false
    }
}















    
  

    
