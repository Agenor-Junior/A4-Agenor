//
//  ViewController02_tableData.swift
//  A4-Agenor
//
//  Created by Agenor Dionizio da Silva Junior on 2025-07-16.
//

import UIKit
import CoreData

class ViewController02_tableData: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var booksTable: UITableView!
 
    var loggedInUsername: String?
    
       var books: [Book] = []

       override func viewDidLoad()
        {
           super.viewDidLoad()
           self.navigationItem.hidesBackButton = true
           if let username = loggedInUsername
            {
               welcomeLabel.text = "Welcome, \(username)"
            }

           booksTable.delegate = self
           booksTable.dataSource = self

           fetchBooks()
        }

       func fetchBooks()
        {
           let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
           let request: NSFetchRequest<Book> = Book.fetchRequest()
            
           do
           {
               books = try context.fetch(request)
               booksTable.reloadData()
           }
            catch
            {
               print("Erro ao buscar livros: \(error.localizedDescription)")
            }
       }

       // ✅ Métodos obrigatórios do UITableViewDataSource:

       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
        {
           return books.count
        }

       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
        {
           let book = books[indexPath.row]

           guard let cell = tableView.dequeueReusableCell(withIdentifier: "BookCell", for: indexPath) as? BookCell
            else
            {
               return UITableViewCell()
            }

           cell.titleBook.text = "\(book.title ?? "") by \(book.author ?? "")"

           if let currentUser = loggedInUsername
            {
               if book.borrower == ""
               {
                   cell.bookStatus.text = "Available – Click to check out"
                   cell.bookStatus.textColor = .systemBlue
               }
               else if book.borrower == currentUser
               {
                   cell.bookStatus.text = "Checked out – Click to return"
                   cell.bookStatus.textColor = .systemOrange
               }
               else
               {
                   cell.bookStatus.text = "Unavailable"
                   cell.bookStatus.textColor = .systemRed
               }
            }

           return cell

       }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let selectedBook = books[indexPath.row]

        guard let currentUser = loggedInUsername else {
            print("Usuário não logado.")
            return
        }

        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

        if selectedBook.borrower == "" {
            // 🔵 Livro disponível → alerta para confirmar empréstimo
            let alert = UIAlertController(
                title: "Borrow Book",
                message: "Do you want to borrow \"\(selectedBook.title ?? "")\"?",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { _ in
                selectedBook.borrower = currentUser
                do {
                    try context.save()
                    self.fetchBooks()
                } catch {
                    print("Erro ao emprestar livro: \(error.localizedDescription)")
                }
            }))
            present(alert, animated: true)

        } else if selectedBook.borrower == currentUser {
            // 🟠 Livro emprestado por mim → alerta para confirmar devolução
            let alert = UIAlertController(
                title: "Return Book",
                message: "Do you want to return \"\(selectedBook.title ?? "")\"?",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { _ in
                selectedBook.borrower = ""
                do {
                    try context.save()
                    self.fetchBooks()
                } catch {
                    print("Erro ao devolver livro: \(error.localizedDescription)")
                }
            }))
            present(alert, animated: true)

        } else {
            // 🔴 Livro emprestado por outro → alerta simples
            let alert = UIAlertController(
                title: "Unavailable",
                message: "This book is currently checked out by another user.",
                preferredStyle: .alert
            )
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }


   }
