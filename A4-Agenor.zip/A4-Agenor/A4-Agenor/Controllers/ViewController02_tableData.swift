//
//  ViewController02_tableData.swift
//  A4-Agenor
//
//  Created by Agenor Dionizio da Silva Junior on 2025-07-16.
//

import UIKit
import CoreData

class ViewController02_tableData: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var booksTable: UITableView!
    
    //Context variable
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var loggedInUsername: String?
    var books: [Book] = []
    
//MARK: - View Did Load
    
       override func viewDidLoad()
        {
           super.viewDidLoad()
           
           if let username = loggedInUsername
            {
               welcomeLabel.text = "Welcome, \(username)"
            }
            
            self.navigationItem.hidesBackButton = true
            navigationItem.rightBarButtonItem = UIBarButtonItem(
               title: "Logout",
               style: .plain,
               target: self,
               action: #selector(logoutTapped)
           )

           booksTable.delegate = self
           booksTable.dataSource = self

           fetchBooks()
        }

 //MARK: - Button Logout
    
        @objc func logoutTapped()
        {
            guard let username = loggedInUsername else { return }

            let alert = UIAlertController(
                title: "Logout",
                message: "\(username), do you want logout?",
                preferredStyle: .alert
            )

            alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))

            alert.addAction(UIAlertAction(title: "Yes", style: .destructive, handler:
            {
                _ in self.navigationController?.popViewController(animated: true)
            } ))

            present(alert, animated: true)
        }
    
 // MARK: - Load table view with books in coreData
    
       func fetchBooks()
       {
           let request: NSFetchRequest<Book> = Book.fetchRequest()
           do
           {
               books = try context.fetch(request)
               booksTable.reloadData()
           }
            catch
            {
               print("Error searching books: \(error.localizedDescription)")
            }
       }

// MARK: - UITableViewDataSource Methods:
    
       //Returns how many rows will be shown
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
       {
        return books.count
    }
    
       // Configures the content of each cell
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
       {
       let book = books[indexPath.row]

       guard let cell = tableView.dequeueReusableCell(withIdentifier: "BookCell", for: indexPath) as? BookCell
       else
        {
           return UITableViewCell()
        }

       cell.titleBook.text = "\(book.title ?? "") by \(book.author ?? "")"

       if let currentUser = loggedInUsername
        {
           if book.borrower == ""
           {
               cell.bookStatus.text = "Available – Click to check out"
               cell.bookStatus.textColor = .systemBlue
           }
           else if book.borrower == currentUser
           {
               cell.bookStatus.text = "Checked out – Click to return"
               cell.bookStatus.textColor = .systemOrange
           }
           else
           {
               cell.bookStatus.text = "Unavailable"
               cell.bookStatus.textColor = .systemRed
           }
        }

       return cell
   }
    
       // Called when user touch cell
       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
       {
           let selectedBook = books[indexPath.row]
        
           guard let currentUser = loggedInUsername
           else
           {
                print("User not logged in.")
                return
            }
            
            if selectedBook.borrower == ""
           {
                showBorrowAlert(for: selectedBook, by: currentUser)
            }
           else if selectedBook.borrower == currentUser
           {
                showReturnAlert(for: selectedBook)
            }
           else
           {
               showUnavailableAlert()
           }
       }
    
//MARK: - Auxiliary functions to didSelectedRowAt
    
       //When Borrow Book
       func showBorrowAlert(for book: Book, by user: String)
        {
            let alert = UIAlertController(
                title: "Borrow Book",
                message: "Do you want to borrow \"\(book.title ?? "")\"?",
                preferredStyle: .alert
            )

            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler:
            { _ in book.borrower = user
                self.saveContextAndRefresh()
            }))

            present(alert, animated: true)
        }

       //When Return Book
       func showReturnAlert(for book: Book)
        {
            let alert = UIAlertController(
                title: "Return Book",
                message: "Do you want to return \"\(book.title ?? "")\"?",
                preferredStyle: .alert
            )

            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler:
            { _ in book.borrower = ""
                self.saveContextAndRefresh()
            }))

            present(alert, animated: true)
        }

       //When Unavailable
       func showUnavailableAlert()
       {
            let alert = UIAlertController(
                title: "Unavailable",
                message: "This book is currently checked out by another user.",
                preferredStyle: .alert
            )

            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
       }
    
       // Save Changes
       func saveContextAndRefresh()
       {
            do
            {
                try context.save()
                fetchBooks()
            }
            catch
            {
                print("Error saving context: \(error.localizedDescription)")
            }
       }
    
}
