//
//  ViewController02_tableData.swift
//  A4-Agenor
//
//  Created by Agenor Dionizio da Silva Junior on 2025-07-16.
//

import UIKit
import CoreData

class ViewController02_tableData: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var booksTable: UITableView!
    
 
    var loggedInUsername: String?
    
       var books: [Book] = []

       override func viewDidLoad() {
           super.viewDidLoad()

           if let username = loggedInUsername {
               welcomeLabel.text = "Welcome, \(username)"
           }

           booksTable.delegate = self
           booksTable.dataSource = self

           fetchBooks()
       }

       func fetchBooks() {
           let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
           let request: NSFetchRequest<Book> = Book.fetchRequest()
           do {
               books = try context.fetch(request)
               booksTable.reloadData()
           } catch {
               print("Erro ao buscar livros: \(error.localizedDescription)")
           }
       }

       // ✅ Métodos obrigatórios do UITableViewDataSource:

       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return books.count
       }

       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell = tableView.dequeueReusableCell(withIdentifier: "BookCell", for: indexPath)
           let book = books[indexPath.row]
           cell.textLabel?.text = "\(book.title ?? "") by \(book.author ?? "")"
           return cell
       }
   }
