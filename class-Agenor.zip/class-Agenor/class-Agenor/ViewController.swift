import UIKit
import CoreLocation
class ViewController: UIViewController, CLLocationManagerDelegate {
    // MARK: Location manager
    var locationManager:CLLocationManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // initialize the locationManager
        self.locationManager = CLLocationManager()
        
        // confrom to the delegate
        self.locationManager.delegate = self
        
        // show the permissions popup box
        self.locationManager.requestWhenInUseAuthorization()
        
        // You should also tell them the reason why you want location
        
        // DEBUG: Check what the user selected
        //        let status = locationManager.authorizationStatus
        //        if (status == .notDetermined) {
        //                 print("DEBUG: Permission status: unknown")
        //        } else if (status == .restricted || status == .denied) {
        //            print("DEBUG: Permission status: restricted or denied")
        //            // TODO: Write code to ask for permission again
        //            // self.locationManager.requestWhenInUseAuthorization()
        //        } else if (status == .authorizedWhenInUse || status == .authorizedAlways) {
        //            print("DEBUG: Permission status:  granted")
        //        }
        
        
        // assuming that you have permission
        // start the process of getting the user's location
        
        // tell the app to start checking for the device location
        print("Calling startUpdateLocation...")
        self.locationManager.startUpdatingLocation()
    }
    
    @IBOutlet weak var Stringtest: UILabel!
    // We need access to functions that will give us this information
    // How we know when the app has a location?
    // How we know if the location changes?
    
    // This function will automatically execute when the app obtains the user location
    // This function is provided by the CLLocationManagerDelegate, so don't forget to set that up!
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // locations = the function parameter
        // When a new location is detected, that location is saved to the locations parameter
        // locations = array of CLLocation objects
        // CLLocation objects -->custom class from CoreData library, adn it represents a
        //  location  = user location, device location, location of a restaurant, location of a city
        
        print("Location obtained!")
        // grab the first location from the array
        if let lastKnownLocation:CLLocation = locations.first {
            print("Lat: \(lastKnownLocation.coordinate.latitude),\(lastKnownLocation.coordinate.longitude)")
            print("Altiude: \(lastKnownLocation.altitude)")     // emulator = 0, if you were standing on a mountain in real life, then alitude would obivously that number
            print("Time/date: \(lastKnownLocation.timestamp)")
            print("Direction in degrees: \(lastKnownLocation.course)") // N = 0/360, E = 90, S = 180, W = 245
            print("Speed: \(lastKnownLocation.speed)") // meters per second
            print("-------")
            
            // output to the label -OPTIONAL
            let output:String = """
                Time/date: \(lastKnownLocation.timestamp)\n
                Lat: \(lastKnownLocation.coordinate.latitude),\(lastKnownLocation.coordinate.longitude)\n
                Altiude: \(lastKnownLocation.altitude)
                Direction in degrees: \(lastKnownLocation.course)
                Speed: \(lastKnownLocation.speed)        
                """
            
            self.Stringtest.text = output
            
        }
        
    }
}

